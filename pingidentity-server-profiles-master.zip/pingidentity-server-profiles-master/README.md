See [server profiles](https://devops.pingidentity.com/how-to/containerAnatomy/) docs for more information.
