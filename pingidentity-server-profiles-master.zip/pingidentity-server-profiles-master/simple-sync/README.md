See [Deploy PingDirectory with data synchronization using PingDataSync](https://pingidentity-devops.gitbook.io/devops/deploy/deploycompose/deploysync) for more information.
