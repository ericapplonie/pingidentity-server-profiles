# WARNING - Example for getting-started use only

The password files in this directory exist as an example to help in
quickly starting up a container with minimal effort.

A secrets management process (i.e vault) should be used whenever dealing
with secrets in a production use case.
