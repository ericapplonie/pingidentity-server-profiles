# Purpose
This directory contains the data that is required to customize pingcentral containers logging.
