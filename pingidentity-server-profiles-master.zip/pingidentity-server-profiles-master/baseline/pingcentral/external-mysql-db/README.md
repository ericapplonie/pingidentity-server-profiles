# Purpose
This directory contains the data that is required to customize pingcentral containers to use an external MySQL database available as service that resolves to the pingcentral-mysql DNS name.

## Credentials
User: Administrator
Password: 2Federate