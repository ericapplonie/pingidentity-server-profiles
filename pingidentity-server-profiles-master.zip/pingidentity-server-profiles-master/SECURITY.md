# Security Warning

The server profiles contained within this repository are for demo and documentation purposes only. As they contain default keys/credentials etc and are not suitable for production and carry a substantial security risk.

Default master keys for this deployment are stored in this publically available repository, a production deployment would keep these files in a safe place to ensure the encryption at rest of production data is secure. Certificate trust policies are also overly permissive for demonstration purposes.
As such, it is ESSENTIAL to cycle the keys in this repository and properly configure certificate trust policies before moving to production.

Please review Ping Identity's product hardening guide for security configuration options. <https://support.pingidentity.com/s/article/Security-Hardening-Guides>
